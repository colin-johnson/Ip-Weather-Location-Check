/**
 * Created by colinjohnson on 5/13/16.
 */
//----------------------------------------------------
// CONSTANTS
//------------------------------------------*/
var request = new XMLHttpRequest();
var weatherCondition;

//------------------------------------------*/
// VARIABLES
/*------------------------------------------*/
var app         = document.getElementById('app'),
    title       = document.getElementById('title'),
    city        = document.getElementById('city'),
    temp        = document.getElementById('temp'),
    icon        = document.getElementById('icon'),
    condition   = document.getElementById('condition');

//------------------------------------------*/
// DATA REQUEST
/*------------------------------------------*/
var dataRequest = {

    geoRequest: function() {
        request.open('GET', 'https://weathersync.herokuapp.com/ip', true);

        request.onload = function () {
            if (request.status >= 200 && request.status < 400) {
                var geoData = JSON.parse(request.responseText);
                console.log(geoData);
                dataRequest.weatherRequest(geoData.location.latitude, geoData.location.longitude);
            } else {
                app.innerHTML = "There was an error retrieving your information, please refresh your browser and try again.";
            }
        };

        request.send();
    },

    weatherRequest: function (lat, lng) {
        request.open('GET', 'https://weathersync.herokuapp.com/weather/' + lat + ',' + lng, true);

        request.onload = function () {
            if (request.status >= 200 && request.status < 400) {
                var weatherData = JSON.parse(request.responseText);
                weatherCondition = {
                    header: "Current conditions for:",
                    city: weatherData.name,
                    temperature: weatherData.main.temp,
                    icon: "http://openweathermap.org/img/w/" + weatherData.weather[0].icon + ".png",
                    condition: weatherData.weather[0].description
                };
                dataRequest.dataReady();
            } else {

            }
        };

        request.send();
    },

    dataReady: function() {
        title.innerHTML = weatherCondition.header;
        city.innerHTML  = weatherCondition.city;
        temp.innerHTML  = weatherCondition.temperature;
        icon.src        = weatherCondition.icon;
        condition.innerHTML   = weatherCondition.condition;
    }
};


dataRequest.geoRequest();

